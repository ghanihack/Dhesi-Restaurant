AOS.init({
  once: true,
});
window.addEventListener("load", AOS.refresh);
