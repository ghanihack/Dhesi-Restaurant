window.addEventListener("load", (event) => {
  var myModal = document.getElementById("delivered");
  var bsModal = new bootstrap.Modal(myModal);
  bsModal.show();
});
